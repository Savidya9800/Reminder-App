package com.example.notifyme

data class Reminder(val id: Int, val title: String, val description: String, val date: String, val time: String)
